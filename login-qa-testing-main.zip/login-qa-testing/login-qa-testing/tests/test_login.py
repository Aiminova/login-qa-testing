"""Automated tests for the login module.
Categories: functional, negative, boundary, security and session management."""
import pytest
from playwright.sync_api import Page, expect
from conftest import VALID_USER, VALID_PASS
from pages.login_page import LoginPage, SecurePage


@pytest.fixture
def login_page(page: Page) -> LoginPage:
    lp = LoginPage(page)
    lp.open()
    return lp


# ---------- Functional (positive) ----------
@pytest.mark.smoke
def test_login_with_valid_credentials(login_page, page):
    login_page.login(VALID_USER, VALID_PASS)
    expect(page).to_have_url("/secure")
    expect(login_page.flash).to_contain_text("You logged into a secure area!")


def test_login_with_enter_key(login_page, page):
    login_page.username.fill(VALID_USER)
    login_page.password.fill(VALID_PASS)
    login_page.password.press("Enter")
    expect(page).to_have_url("/secure")


# ---------- Negative ----------
@pytest.mark.negative
@pytest.mark.parametrize(
    "user,pwd,expected",
    [
        ("wrong_user", VALID_PASS, "Your username is invalid!"),
        (VALID_USER, "wrong_password", "Your password is invalid!"),
        ("", "", "Your username is invalid!"),
        ("", VALID_PASS, "Your username is invalid!"),
        (VALID_USER, "", "Your password is invalid!"),
        ("TomSmith", VALID_PASS, "Your username is invalid!"),        # username is case-sensitive
        (VALID_USER, "supersecretpassword!", "Your password is invalid!"),  # password is case-sensitive
        (f" {VALID_USER} ", VALID_PASS, "Your username is invalid!"),  # leading/trailing spaces
    ],
    ids=["wrong-username", "wrong-password", "both-empty", "username-empty",
         "password-empty", "username-case", "password-case", "username-with-spaces"],
)
def test_invalid_login_shows_error(login_page, page, user, pwd, expected):
    login_page.login(user, pwd)
    expect(login_page.flash).to_contain_text(expected)
    expect(page).to_have_url("/login")


# ---------- Boundary ----------
@pytest.mark.boundary
def test_very_long_input_is_rejected_gracefully(login_page, page):
    login_page.login("a" * 1000, "b" * 1000)
    expect(login_page.flash).to_contain_text("invalid")
    expect(page).to_have_url("/login")


# ---------- Security ----------
@pytest.mark.security
@pytest.mark.parametrize("payload", ["' OR '1'='1", "admin'--", '" OR ""="'])
def test_sql_injection_does_not_bypass_login(login_page, page, payload):
    login_page.login(payload, payload)
    expect(page).to_have_url("/login")
    expect(login_page.flash).to_contain_text("invalid")


@pytest.mark.security
def test_xss_payload_is_not_executed(login_page, page):
    dialogs = []
    page.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
    login_page.login("<script>alert(1)</script>", "<img src=x onerror=alert(2)>")
    page.wait_for_timeout(500)
    assert dialogs == [], "The XSS payload was executed!"


@pytest.mark.security
def test_password_field_is_masked(login_page):
    expect(login_page.password).to_have_attribute("type", "password")


# ---------- Session management ----------
@pytest.mark.security
def test_secure_page_requires_authentication(page):
    page.goto("/secure")
    expect(page).to_have_url("/login")
    expect(LoginPage(page).flash).to_contain_text("You must login to view the secure area!")


@pytest.mark.smoke
def test_logout_ends_session(login_page, page):
    login_page.login(VALID_USER, VALID_PASS)
    SecurePage(page).logout()
    expect(page).to_have_url("/login")
    expect(login_page.flash).to_contain_text("You logged out of a secure area!")
    page.goto("/secure")  # after logout, the protected page must be inaccessible again
    expect(page).to_have_url("/login")
