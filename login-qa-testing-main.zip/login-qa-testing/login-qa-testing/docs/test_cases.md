# Login Test Cases

| ID | Category | Scenario | Steps | Expected Result | Priority |
|---|---|---|---|---|---|
| LG-01 | Functional | Valid login | Log in with correct username/password | /secure opens, success message shown | Critical |
| LG-02 | Functional | Login with Enter key | Press Enter in the password field | User is logged in | Medium |
| LG-03 | Negative | Wrong username | Invalid username + correct password | "username is invalid" | High |
| LG-04 | Negative | Wrong password | Correct username + wrong password | "password is invalid" | High |
| LG-05 | Negative | Both fields empty | Submit empty form | Error shown, stays on login page | High |
| LG-06 | Negative | Only username empty | Password filled | Error shown | Medium |
| LG-07 | Negative | Only password empty | Username filled | "password is invalid" | Medium |
| LG-08 | Negative | Username letter case | "TomSmith" | Login is rejected | Medium |
| LG-09 | Negative | Password letter case | All-lowercase password | Login is rejected | High |
| LG-10 | Negative | Leading/trailing spaces | " tomsmith " | Login is rejected | Low |
| LG-11 | Boundary | 1000-character input | Enter very long text | Error shown, no crash | Medium |
| LG-12 | Security | SQL injection | `' OR '1'='1` etc. | Login cannot be bypassed | Critical |
| LG-13 | Security | XSS | `<script>alert(1)</script>` | Script does not execute | Critical |
| LG-14 | Security | Password masking | Password field | type=password, no plain text shown | High |
| LG-15 | Session | Unauthorized access | Open /secure without logging in | Redirect to login with a warning | Critical |
| LG-16 | Session | Logout | Click Logout | Login page and logout message | High |
| LG-17 | Session | Access after logout | Open /secure after logout | Redirected to login again | Critical |

## Manual / Extra Checklist (not automated)
- Cross-browser appearance and behavior (Chrome, Firefox, Safari)
- Mobile layout and keyboard behavior
- Accessibility: tab order, labels, screen reader
- "Remember me" and password manager compatibility (if present)
- User enumeration risk: do error messages reveal whether the username or the password was wrong?
