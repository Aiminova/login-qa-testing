# Login Module Test Plan

## Objective
Verify the functional correctness of the authentication flow (login/logout), its error handling and its basic security behavior.

## Scope
- **In scope:** valid/invalid login, empty fields, letter case, whitespace, very long input, SQL injection and XSS attempts, password masking, unauthorized page access, session state after logout.
- **Out of scope:** brute-force/rate limiting, forgot password, 2FA, performance and load testing (not present in the application or would need separate tooling).

## Approach
| Technique | How I applied it |
|---|---|
| Equivalence partitioning | Valid and invalid groups for username and password |
| Boundary values | Empty input and a 1000-character input |
| Negative testing | 8 different invalid login combinations |
| Security | SQL injection, XSS, masking, session checks |
| Automation | Playwright + pytest with Page Object Model |

## Entry / Exit Criteria
- Entry: the environment is reachable and the test user is defined.
- Exit: all `smoke` and `security` tests pass and no Blocker/Critical defect is open.

## Risks
The third-party demo site can change or become temporarily unavailable.
