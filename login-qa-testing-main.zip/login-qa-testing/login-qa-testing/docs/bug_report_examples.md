# Sample Bug Reports

## BUG-001 - [Login] Error messages reveal which usernames are valid
- **Severity:** Major | **Priority:** P2 | **Type:** Security
- **Steps:** 1) Enter a valid username with a wrong password 2) Enter an invalid username with a wrong password
- **Actual:** Two different messages ("password is invalid" / "username is invalid")
- **Expected:** One generic message, e.g. "Username or password is incorrect"
- **Impact:** An attacker can discover valid usernames (user enumeration).

## BUG-002 - [Login] Username with surrounding spaces is rejected (example / suggestion)
- **Severity:** Minor | **Priority:** P3
- **Steps:** Log in with " tomsmith "
- **Actual:** Login is rejected
- **Expected:** Input is trimmed, or a clear warning is shown
