"""Page Object Model: locators and actions for the login and secure-area pages."""
from playwright.sync_api import Page


class LoginPage:
    def __init__(self, page: Page):
        self.page = page
        self.username = page.locator("#username")
        self.password = page.locator("#password")
        self.submit = page.locator("button[type='submit']")
        self.flash = page.locator("#flash")

    def open(self):
        self.page.goto("/login")

    def login(self, user: str, pwd: str):
        self.username.fill(user)
        self.password.fill(pwd)
        self.submit.click()


class SecurePage:
    def __init__(self, page: Page):
        self.page = page
        self.logout_button = page.locator("a.button.secondary")
        self.flash = page.locator("#flash")
        self.heading = page.locator("h2")

    def logout(self):
        self.logout_button.click()
